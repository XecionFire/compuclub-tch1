<?php

require_once __DIR__ . "\..\Http\Setting\setting.php";
require_once __DIR__ . "\..\Http\Controller\controller.php";